import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

class Header extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {

        return (
            <div id="header_3">
				<div class="container_3">
						
						<h1 id="logo_3">QUIZ</h1>
					    <nav className="nav">
                            <ul className="nav__menu">
                            <li className="nav__menu-item">
                                <a>Home</a>
                            </li>
                            <li
                                className="nav__menu-item"
                            >
                                <Link to="/quiz/packagelist"><a>Package</a></Link>
                                <Submenu />
                            </li>
                            <li className="nav__menu-item">
                                <a>Quiz</a>
                            </li>
                            <li className="nav__menu-item">
                                <a>Notice</a>
                            </li>
                            <li className="nav__menu-item">
                                <a>QnA</a>
                            </li>
                            </ul>
                        </nav>
						<div id="banner_3">
							<div className="container_3">
								<section>
									<button className="singlebutton5"><Link to="/auth/register">Sign Up</Link></button>
								</section>			
							</div>
						</div>

				</div>
			</div>
        );
    }
}

class Submenu extends React.Component {
    render() {
      return (
        <ul className="nav__submenu">
          <li className="nav__submenu-item ">
            <a>1</a>
          </li>
          <li className="nav__submenu-item ">
            <a>2</a>
          </li>
          <li className="nav__submenu-item ">
            <a>3</a>
          </li>
        </ul>
      )
    }
  }

export default Header;
