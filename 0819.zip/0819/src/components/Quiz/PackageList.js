import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import PackageItem from './PackageItem';
import 'whatwg-fetch';
import { connect } from 'react-redux';
import axios from 'axios';
import update from 'react-addons-update';

class PackageList extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            packageData: [{
                num: 0,
                title: '어쩌고',
                content: '저쩌고',
                tt: true
            },
            {
                num: 1,
                title: '어쩌고',
                content: '저쩌고',
                tt: false
            }],
            Alldata: [],
            loginData: {},
            delete: [],
            copy: []
        };
    }

    render() {
        const View = this.state.packageData.map(data => {
            return <PackageItem num={data.num}
                        packageName={data.title}
                        content={data.content}
                        key={data.num}
                        tt={data.tt}/>
          });

        return (
            <div style={{marginTop:'30px', marginRight:'10px'}}>
                <div style={{width:'85%'}}>{View}</div>
            </div>
        );
    }
}

export default PackageList;