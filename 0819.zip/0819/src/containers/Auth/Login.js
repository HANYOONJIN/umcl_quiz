import React, { Component } from 'react';
import { Authentication } from 'components/Auth';
import { connect } from 'react-redux';

class Login extends React.Component {

    constructor(props) {
        super(props);
    }
    render() {
        return (
            <Authentication mode={true} onLogin={this.handleLogin}/>
        );
    }
}
 
export default Login;