import React, { Component } from 'react';
import { Authentication } from 'components/Auth';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
 

class Register extends Component {

    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                <Authentication mode={false}/>
            </div>
        );
    }
}

export default Register;
