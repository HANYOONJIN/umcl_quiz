import React, { Component } from 'react';
import Header from 'components/Base/Header';
import { connect } from 'react-redux';

class HeaderContainer extends Component {

    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                <Header/>
            </div>
        );
    }
}

export default HeaderContainer;