import React, { Component } from 'react';
import { PackageList } from 'components/Quiz';
import { connect } from 'react-redux';

class WritePackage extends React.Component {

    constructor(props) {
        super(props);
    }
    render() {
        return (
            <PackageList/>
        );
    }
}
 
export default WritePackage;