import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route } from 'react-router-dom';
import App from './App';
import './index.css';
import './style.css';

import { Provider } from 'react-redux';


const rootElement = document.getElementById('root');

ReactDOM.render(
    <Provider>
        <BrowserRouter>
            <Route path="/" component={App}/>
        </BrowserRouter>
    </Provider>, rootElement
);
