import React from 'react';
import { Route } from 'react-router-dom';
import { PackageList, WritePackage, ReadPackage } from 'containers/Quiz';

class Quiz extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <Route path="/quiz/packagelist" component={PackageList}/>
                <Route path="/quiz/writepackage" component={WritePackage}/>
                <Route path="/quiz/readpackage" component={ReadPackage}/>
            </div>
        );
    }
}

export default Quiz;
