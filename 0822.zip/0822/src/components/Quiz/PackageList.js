import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import PackageItem from './PackageItem';
import 'whatwg-fetch';
import { connect } from 'react-redux';
import axios from 'axios';
import update from 'react-addons-update';

class PackageList extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            packageListData: [],
            packageData: [{
                num: 0,
                title: '어쩌고',
                content: '저쩌고',
                tt: true
            },
            {
                num: 1,
                title: '어쩌고',
                content: '저쩌고',
                tt: false
            }],
            Alldata: [],
            loginData: {},
            delete: [],
            copy: []
        };
    }

    componentDidMount() {
        this.getPackageList();
    }

    getPackageList() {
        axios.get('/api/board/packageList')
		.then((response) => {
            console.log(response.data.data);
            this.setState({
                packageListData : response.data.data.map(
                    info => ({
                        num: info.num,
                        title: info.title,
                        content: info.content
                    })
                )
            });
		})
		.catch((err)=>{
			console.log('Error fetching packageList',err);
        });
    }

    render() {
        const View = this.state.packageListData.map(data => {
            return <PackageItem num={data.num}
                        packageName={data.title}
                        content={data.content}
                        key={data.num}
                        tt={true}/>
          });

        const bar = (
            <div className="header-wrap">
                <button className="singlebutton6" style={{right:'10px', position:'fixed'}} onClick={this.props.newlink}>CREATE</button>
            </div>
        );

        return (
            <div style={{marginTop:'30px', marginRight:'10px'}}>
                <div style={{width:'85%'}}>{View}</div>
                {bar}
            </div>
        );
    }
}

PackageList.propTypes = {
    newlink: PropTypes.func,
};
 
PackageList.defaultProps = {
    newlink: () => { console.error("newlink function not defined"); },
};

export default PackageList;