import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import OptionItem from './OptionItem';
import axios from 'axios';
import update from 'react-addons-update';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

const Wrapper = {
    marginTop: '1rem'
}

// 너비, 그림자 설정
const ShadowedBox = {
    background: 'white',
    marginTop: '0.1rem'
}

const ShadowedBox2 = {
    background: 'white'
}

// 로고
const LogoWrapper = {
    background: 'gray',
    height: '0.2rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const LogoWrapper2 = {
    background: 'gray',
    height: '0.1rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const ButtonStyle = {
    cursor: 'pointer',
    display: 'inline',
    color:'rgb(255, 106, 106)'
}

const ButtonStyle2 = {
    cursor: 'pointer',
    color:'red', 
    fontSize:'30px', 
    right:'5px', 
    position:'absolute',
    marginTop:'5px'
}

class QuizItem extends Component {

    constructor(props) {
        super(props);

        this.state = {
            option : [
                {
                    num: 0,
                    content: '',
                    check: false
                }
            ]
        };

        this.num = 1;
        this.numnum = 0;

        this.number = this.props.num;
        this.quiztitle = '퀴즈 내용';
        this.value = '';
        this.quizoption = [];
        this.dbNum = null;
        this.score = 1;

        this.quizDelete = this.quizDelete.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleCreate = this.handleCreate.bind(this);
        this.handledelete = this.handledelete.bind(this);
        this.selectChange = this.selectChange.bind(this);
        this.handleoptionChange = this.handleoptionChange.bind(this);
    }
    
    componentDidUpdate(){
        const { onUpload } = this.props;
        onUpload(this.dbNum, this.number, this.quiztitle, this.state.option, this.value, this.score);
    }

    handleChange(e){
        this[e.target.name] = e.target.value;
    }

    handleCreate(){
        this.setState({
            option : this.state.option.concat({
                num: this.num++,
                content: '',
                check: false
            })
        });
        this.numnum++;
    }

    handledelete(number){
        if(this.numnum>0){
            this.numnum--;
        }

        console.log(number);

        this.setState({
            option: this.state.option.filter(info => info.num !== number)
          })

    }
    
    handleoptionChange(number, optioncontent, check) {
        this.setState({
            option : this.state.option.map(
                info => number === info.num
                ? {
                    num: number,
                    content: optioncontent,
                    check: check
                    }
                : info
              )
        });
    }

    selectChange(e) {
        this.value = e.target.value;
    }

    quizDelete() {
    }

    render() {
        const quizContentView = (
            <div>
                <div>
                    <input name="quiztitle" placeholder="질문" type="text" style={{fontSize:'17px', color:'gray', placeholder:'gray'}}
                    onChange={this.handleChange}
                    value={this.quiztitle}
                    />
                    <div className="optionStyle">
                        <label htmlFor="select1" className="optionStyle" style={{fontSize:'20px', color:'darkGray'}}><b>#</b></label>
                        <input type="text" placeholder=" '#tag' 형식으로 입력하세요" name="value" value={this.value} onChange={this.handleChange} className="optionStyle"
                        style={{fontSize:'12px', width:'70%', color:'gray', placeholder:'gray'}}/>
                    </div> &nbsp;&nbsp;
                    <select className="optionStyle"style={{width:'21%', fontSize:'12px'}}>
                        <option value="level">난이도</option>
                        <option value="high">&nbsp;&nbsp;상</option>
                        <option value="middle">&nbsp;&nbsp;중</option>
                        <option value="low">&nbsp;&nbsp;하</option>
                    </select>
                </div>
            </div>
        );

        const buttonView = (
                <span style={Wrapper}>
                    <i className="material-icons optionStyle" style={ButtonStyle}>radio_button_unchecked</i>
                    &nbsp;&nbsp;
                    <input type="text" style={{fontSize:'12px', width:'50%', color:'rgb(255, 106, 106)', borderColor:'rgb(255, 106, 106)', cursor: 'pointer'}}
                        value='옵션 추가'
                        className="optionStyle"
                        disabled/> 
                    &nbsp;
                </span>
        );


        const writeoptionList = this.state.option.map(
            data => (
              <OptionItem
                num={data.num}
                mode={true}
                content={data.content}
                check={data.check}
                key={data.num}
                onDelete={this.handledelete}
                onoptionChange={this.handleoptionChange}
              />
            )
          );

        const readoptionList = this.state.option.map(
            data => (
              <OptionItem
                num={data.num}
                mode={false}
                content={data.content}
                check={data.check}
                key={data.num}
              />
            )
          );

        const writeView = (
            <div style={ShadowedBox} className="ShadowedBox card-2">
                   <div style={LogoWrapper}></div>
                    <div style={Contents}>
                                { quizContentView }
                                { writeoptionList }
                                <div style={{marginTop: '1.5rem'}}>
                                    <span onClick={this.handleCreate}> 
                                        { this.numnum <= 10 ? buttonView : null } 
                                    </span>
                                    <span style={{color:'gray', marginLeft:'15%', fontSize:'12px'}} >
                                        <b>점수</b>&nbsp;&nbsp;&nbsp;
                                        <input type="number" min="1" max="10" step="1" className="optionStyle" style={{width:'8%', fontSize:'12px'}}
                                            name="score" value={this.score}
                                            onChange={this.handleChange}/>
                                    </span>
                                </div>
                            </div>
                        </div>
        );

        const readView = (
            <div style={ShadowedBox2} className="ShadowedBox card-3">
                   <div style={LogoWrapper2}></div>
                    <div style={Contents}>
                        <div>
                            <div name="quiztitle" style={{fontSize:'17px', width:'70%', color:'gray'}}
                            className="optionStyle">{this.quiztitle}</div>
                        </div>
                        { readoptionList }
                    </div>
                </div>
        );
        return (
            <div>
                {this.props.mode ? writeView : readView}
            </div>
        );
    }
}

decorate(QuizItem, {
    num : observable,
    numnum : observable,
    quizoption : observable,
    number : observable,
    quiztitle : observable,
    value : observable,
    quizoption: observable,
    dbNum : observable,
    score : observable,

    handleCreate : action,
    handleoptionChange : action
  })

export default observer(QuizItem);