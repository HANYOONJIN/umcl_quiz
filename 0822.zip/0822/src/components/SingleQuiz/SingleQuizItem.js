import React from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { autorun } from 'mobx';
import PropTypes from 'prop-types';

const Title = {
    fontSize: '1rem',
    color: 'gray',
    textAlign: 'left',
    display: 'inline-block',
    paddingLeft: '1rem',
    width: '80%'
}

const Positioner = {
    marginTop: '1.5rem',
    width: '500px',
    height: '60px',
    background: 'white',
    display: 'inline-block'
}

const Label = {
    fontSize: '1rem',
    color: 'gray',
    textAlign: 'right',
    display: 'inline-block',
    paddingRight: '1rem',
    width: '20%'
}

class SingleQuizItem extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            bool : false,
            tagArray: ['123','456','789'],
            checked : false
        }
    }

    render() {
        //const { num, username, deleteMode } = this.props;
        //let link_save = '/quiz/singleQuiz/' + num + '/' + username;
        //let link_read = '/quiz/singleRead/' + num + '/' + username;
        const tag =
            this.state.tagArray.map(data => (
                <span><a style={{backgroundColor:'green', color:'white', fontSize:'11px', padding:'0.1px'}} onClick={() => this.tagClick(data)}>{data}</a>&nbsp;&nbsp;</span>
                )
            )

        return (
            <div>
                <div style={Positioner} className='card-3'>
                    <div style={Title}><b>{this.props.quizName}</b></div>
                    <div style={Label}>{tag}</div>
                </div>
            </div>
        );
    }
}

export default SingleQuizItem;