import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import axios from 'axios';
import update from 'react-addons-update';
import { connect } from 'react-redux';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"
import { QuizItem } from 'components/Quiz';


const Wrapper = {
    marginTop: '1rem'
}


const Positioner = {
    position: 'absolute',
    left: '50%',
    marginTop: '4rem',
    marginBottom: '4rem',
    transform: 'translate(-50%, 0)'
}

const Positioner2 = {
    position:'fixed',
    right:'5%',
    top:'50%',
    cursor: 'pointer'
}

// 너비, 그림자 설정
const ShadowedBox = {
    marginTop: '1rem'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const Contents2 = {
    background: 'white',
    height: 'auto'
}


const ButtonStyle = {
    marginTop: '2rem',
    marginLeft: '2rem',
    marginBottom: '2rem',
    paddingTop: '0.6rem',
    paddingBottom: '0.5rem',
    background: 'gray',
    color: 'white',
    textAlign: 'center',
    fontSize: '1.25rem',
    fontWeight: '500',
    cursor: 'pointer',
    userSelect: 'none',
    transition: '.2s all',
    width: '20%',
    borderRadius:'5px'
}

class ReadPackage extends Component {

    constructor(props) {
        super(props);

        this.packagetitle = '패키지 제목';
        this.packagecontent = '패키지 설명';
        this.packagenum = 0;
        this.quizlist = {};
        this.quiznum = 0;
        this.quiz = [{num:0, content:'123'},{num:1, content:'123'},{num:2, content:'123'}];
        this.submitQuiz = [];
        this.finalScore = 0;
        this.totalScore = 0;
        this.componentChange = false;
        this.resultConfirm = true;
        this.uploadNum = null;
        this.uploadList = '';

        this.session = {};

    }

    render() {

        const quizView = (
            <div>
                <div style={Wrapper}>
                    <div name="packagetitle" style={{fontSize:'25px', color:'black'}}>
                        {this.packagetitle}
                    </div>
                </div>
                <div style={Wrapper}>
                    <div name="packagecontent" style={{fontSize:'15px', color:'gray'}}>
                        {this.packagecontent}
                    </div>
                </div>
            </div>
        );

        const quizcontentList = this.quiz.map(
            data => (
              <QuizItem
                mode={false}
                num={data.num}
                content={data.content}
                key={data.num}
                onDelete={this.handleDelete}
              />
            )
          );

        return (
            <div>
                    <div style={Positioner}>
                        <div style={ShadowedBox} className="ShadowedBox card-3">
                            <div style={Contents}>
                                { quizView }
                            </div>
                        </div>
                        <div style={Contents2}>
                            { quizcontentList }
                        </div>
                        <div style={Contents2} className="card-3">
                            <button className="b01_simple_rollover" 
                            style={{marginLeft:'50px', marginBottom:'30px', marginTop:'30px'}}
                            onClick={this.handleInsert}>&nbsp;제&nbsp;&nbsp;&nbsp;출&nbsp;</button>
                        </div>
                    </div>
            </div>
        );
    }
}

decorate(ReadPackage, {
    packagetitle: observable,
    packagecontent: observable,
    packagenum: observable,
    quiznum: observable,
    quizlist: observable,
    quiz: observable,
    answer: observable,
    finalScore: observable,
    totalScore: observable,
    submitQuiz: observable,
    componentChange: observable,
    session: observable,
    uploadNum: observable,
    resultConfirm: observable,
    uploadList: observable,

    getQuizList: action,
    handleSubmit: action,
    handleInsert: action,
    linkFunction: action,
    confirm: action
  })

export default observer(ReadPackage);