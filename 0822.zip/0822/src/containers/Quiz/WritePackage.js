import React, { Component } from 'react';
import { connect } from 'react-redux';
import { QuizItem } from 'components/Quiz';
import axios from 'axios';
import update from 'react-addons-update';

import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

const Wrapper = {
    marginTop: '1rem'
}


const Positioner = {
    position: 'absolute',
    left: '50%',
    marginTop: '4rem',
    marginBottom: '4rem',
    transform: 'translate(-50%, 0)'
}

const Positioner2 = {
    position:'fixed',
    right:'5%',
    top:'50%',
    cursor: 'pointer'
}

// 너비, 그림자 설정
const ShadowedBox = {
    marginTop: '1rem'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const Contents2 = {
    background: 'white',
    height: 'auto'
}

class WritePackage extends Component {

    constructor(props) {
        super(props);

        this.state = {
            loginData: {}
        }

        this.num = 0;
        this.answer = '';
        this.AorB = true;

        this.bool = false;

        this.quiz = [{num:0, content:'123'},{num:1, content:'123'},{num:2, content:'123'}];
        this.packagetitle = '';
        this.packagecontent = '';
        this.packagenum = 0;
        this.quizlist = [];
        this.uploadQuiz = [];
        this.uploadList = '';

        this.handleChange = this.handleChange.bind(this);
        this.handleCreate = this.handleCreate.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.selectChange = this.selectChange.bind(this);
        this.turnBool = this.turnBool.bind(this);

    }
    
    handleChange(e){
        this[e.target.name] = e.target.value;
    }

    handleCreate(){
        console.log(this.quiz);
        this.quiz = this.quiz.concat({
            num: this.num++,
            content: null
            })

        this.uploadQuiz = this.uploadQuiz.concat({
            dbnum: null,
            quiztitle: '',
            quizoption: [],
            value: '',
            optionlist: '',
            score: 0
                })
    }

    selectChange(e) {
        this.setState({
          value: e.target.value
        })
    }

    turnBool(){
        this.bool = !this.bool;
    }

    handleDelete(number) {
        if(this.num>0){
            this.num--;
        }

        console.log(number);

        this.quiz = this.quiz.filter(info => info.num !== number);

        let arr = this.uploadQuiz;
        arr.splice(number, 1);

        this.uploadQuiz = arr;
    }

    render() {
        const quizView = (
            <div>
                <div style={Wrapper}>
                    <input name="packagetitle" placeholder="packagetitle" type="text" style={{fontSize:'25px', color:'gray', placeholder:'gray'}}
                    onChange={this.handleChange}
                    value={this.packagetitle}/>
                </div>
                <div style={Wrapper}>
                    <input name="packagecontent" placeholder="packagecontent" type="text" style={{fontSize:'15px', color:'gray', placeholder:'gray'}}
                    onChange={this.handleChange}
                    value={this.packagecontent}/>
                </div>
            </div>
        );

        const buttonView = (
            <div>
                <i className="material-icons" style={{color:'gray', fontSize:'40px'}}>add_circle</i>
            </div>
        );


        const quizcontentList = this.quiz.map(
            data => (
              <QuizItem
                mode={true}
                num={data.num}
                content={data.content}
                key={data.num}
                onDelete={this.handleDelete}
              />
            )
          );


        return (
            <div>
                <div style={Positioner}>
                <button className="savebutton" onClick={this.handleInsert}>S&nbsp;&nbsp;A&nbsp;&nbsp;V&nbsp;&nbsp;E</button>
                    <div style={ShadowedBox} className="ShadowedBox card-2">
                        <div style={Contents}>
                            { quizView }
                        </div>
                    </div>
                    <div style={Contents2}>
                        { quizcontentList }
                    </div>
                </div>
                <div style={Positioner2}>
                    <div onClick={this.handleCreate}> { buttonView } </div>
                    <br/>
                    <div onClick={this.turnBool}>
                        <i className="material-icons" style={{color:'gray', fontSize:'40px'}}>library_add</i>
                    </div>
                </div>
            </div>
        );
    }
}


decorate(WritePackage, {
    packagetitle : observable,
    packagecontent : observable,
    packagenum : observable,
    quizlist : observable,
    quiz : observable,
    uploadQuiz : observable,
    answer : observable,
    AorB : observable,
    bool : observable,

    turnBool : action,
    selectChange : action,
  })
 
export default observer(WritePackage);