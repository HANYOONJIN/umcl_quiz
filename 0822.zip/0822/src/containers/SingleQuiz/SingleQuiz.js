import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { SingleQuizItem } from 'components/SingleQuiz';
import 'whatwg-fetch';
import axios from 'axios';
import update from 'react-addons-update';

const Positioner = {
    position: 'absolute',
    left: '50%',
    transform: 'translate(-50%, 0)',
    marginTop:'3%', 
    textAlign:'center'
}

const linkDiv = {
    marginBottom: '1rem',
    textAlign: 'right',
    color: 'gray'
}


class SingleQuiz extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            items : 10,
            preItems : 0,
            loginData: {},
            list : [{quizname:'HTML이란?',tag:'123'},{quizname:'C++에서 쓰이는 키워드가 아닌 것은?',tag:'123'},{quizname:'Javascript에서 쓰이는 키워드는?',tag:'123'}],
            listAll : [],
            delete: [],
            tag: false
        }

        this.infiniteScroll = this.infiniteScroll.bind(this);

    }

    componentDidMount() {
        window.addEventListener('scroll', this.infiniteScroll, true);
    }

    componentWillUnmount() {
        window.removeEventListener('scroll', this.infiniteScroll, true);
    }


    infiniteScroll() {
        if(document.getElementById('search').value == '' && !this.state.tag){
            let scrollHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);

            let scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);

            let clientHeight = document.documentElement.clientHeight;

            if(scrollTop + clientHeight === scrollHeight){
                console.log(this.state.items);
                console.log(this.state.preItems);
                this.setState({
                    preItems: this.state.items,
                    items: this.state.items+10
                })
            }
        }
    }

    render() {
        const View = (
            this.state.list.map((data, i) => {
                return (<SingleQuizItem num={data.num}
                                arrayNum={i}
                                quizName={data.quizname}
                                tag={data.tag}
                                key={i}/>);
                }
            )
        );
        return (
            <div>
                <div style={Positioner}>
                    {View}
                </div>
            </div>
            
        );
    }
}

export default SingleQuiz;