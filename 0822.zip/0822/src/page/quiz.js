import React from 'react';
import { Route } from 'react-router-dom';
import { PackageListC, WritePackage, ReadPackage, NewPackage } from 'containers/Quiz';
import { SingleQuiz } from 'containers/SingleQuiz';

class Quiz extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <Route path="/quiz/packagelist" component={PackageListC}/>
                <Route path="/quiz/writepackage" component={WritePackage}/>
                <Route path="/quiz/readpackage" component={ReadPackage}/>
                <Route path="/quiz/singlequiz" component={SingleQuiz}/>
                <Route path="/quiz/newpackage" component={NewPackage}/>
            </div>
        );
    }
}

export default Quiz;
