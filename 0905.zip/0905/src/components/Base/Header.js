import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

class Header extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {

      const loginButton = (
        <button className="singlebutton5" onClick={this.props.Loginlink}>LOGIN</button>
      );
      const logoutButton = (
        <button className="singlebutton5" onClick={this.props.onLogout}>LOGOUT</button>
      );
      const registerButton = (
        <button className="singlebutton5" onClick={this.props.Registerlink}>JOIN</button>
      );
      const modifyButton = (
        <button className="singlebutton5">MODIFY</button>
      );

      //style={{boxShadow: 'none'}}

        return (
          <div id="header_3">
				    <div>
						
              <Link to='/'><h1 id="logo_3">QUIZ</h1></Link>
					    <nav className="nav">
                            <ul className="nav__menu">
                            <li className="nav__menu-item">
                                <Link to='/'>홈</Link>
                            </li>
                            <li
                                className="nav__menu-item"
                            >
                                <Link to={this.props.isLoggedIn ? "/quiz/packagelist" : "/auth/fail"}>문제집</Link>
                                <Submenu1 isLoggedIn={this.props.isLoggedIn}/>
                            </li>
                            <li className="nav__menu-item">
                                <Link to={this.props.isLoggedIn ? "/quiz/singlequiz" : "/auth/fail"}>문제</Link>
                                <Submenu2 isLoggedIn={this.props.isLoggedIn}/>
                            </li>
                            <li className="nav__menu-item">
                                <a></a>
                            </li>
                            <li className="nav__menu-item">
                                <a></a>
                            </li>
                            </ul>
                        </nav>
						<div id="banner_3">
							<div>
								<section>
                  { this.props.isLoggedIn ? logoutButton : loginButton }
                  { this.props.isLoggedIn ? modifyButton : registerButton }
								</section>			
							</div>
						</div>

				</div>
			</div>
        );
    }
}

class Submenu1 extends React.Component {
    render() {
      return (
        <ul className="nav__submenu">
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/packagelist" : "/auth/fail"}>전체 문제집</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/existPackageList" : "/auth/fail"}>풀었던 문제집</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/noneExistPackageList" : "/auth/fail"}>풀지 않은 문제집</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/minePackageList" : "/auth/fail"}>내가 낸 문제집</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/anotherPackageList" : "/auth/fail"}>남이 낸 문제집</Link>
          </li>
          <li className="nav__submenu-item ">
            추천 문제집
          </li>
        </ul>
        )
      }
    }

class Submenu2 extends React.Component {
    render() {
      return (
        <ul className="nav__submenu">
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/singlequiz" : "/auth/fail"}>전체 문제</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/existQuiz" : "/auth/fail"}>풀었던 문제</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/noneExistQuiz" : "/auth/fail"}>풀지 않은 문제</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/mineQuiz" : "/auth/fail"}>내가 낸 문제</Link>
          </li>
          <li className="nav__submenu-item ">
            <Link to={this.props.isLoggedIn ? "/quiz/anotherQuiz" : "/auth/fail"}>남이 낸 문제</Link>
          </li>
          <li className="nav__submenu-item ">
            추천 문제
          </li>
        </ul>
        )
      }
    }

Header.propTypes = {
  isLoggedIn: PropTypes.bool,
  onLogout: PropTypes.func,
  Loginlink: PropTypes.func,
  Registerlink: PropTypes.func
};

Header.defaultProps = {
  isLoggedIn: false,
  onLogout: () => { console.error("logout function not defined");},
  Loginlink: () => { console.error("Loginlink function not defined");},
  Registerlink: () => { console.error("Registerlink function not defined");}
};

export default Header;
