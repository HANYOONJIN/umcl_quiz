export { default as SingleQuizC } from './SingleQuizC';
export { default as anotherQuiz } from './anotherQuiz';
export { default as mineQuiz } from './mineQuiz';
export { default as existQuiz } from './existQuiz';
export { default as noneExistQuiz } from './noneExistQuiz';

export { default as WriteQuiz } from './WriteQuiz';
export { default as ReadQuiz } from './ReadQuiz';
export { default as NewQuiz } from './NewQuiz';