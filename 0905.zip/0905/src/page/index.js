export { default as Home } from './home';
export { default as Quiz } from './quiz';
export { default as Auth } from './auth';